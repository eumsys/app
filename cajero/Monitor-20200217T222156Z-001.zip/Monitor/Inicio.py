# coding=utf-8

__author__ = "Sigfrido"
__date__ = "$06-jun-2019 20:09:20$"

import Controlador

def main ():
    Controlador.Controlador()


if __name__ == "__main__":
    main ()